<?php

require_once './interfejsi/Renderable.php';
require_once './modeli/MenuItem.php';
require_once './modeli/Menu.php';

?>